<!DOCTYPE html>
<html lang="en-US">
    <head>
        <title>Page Not Found</title>
        <meta name="Keywords" content="">
        <meta name="Description" content="Build awesome web pages online and offline, for WordPress and Joomla!">

        <meta property="og:type" content="website">
        <meta property="og:url" content="https://nicepage.com/">
        <meta property="og:title" content="Page Not Found">
        <meta property="og:description" content="Build awesome web pages online and offline, for WordPress Joomla!">
        <meta property="og:site_name" content="Nicepage.com" />
        
        <meta charset="utf-8" />
		<meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no,width=device-width">
        
		<style>
			html, body {
				position: relative;
				height: 100%;
				margin: 0;
				padding: 0;
				color: #333;
				-webkit-font-smoothing: antialiased;
				-webkit-text-size-adjust: 100%;
				-ms-text-size-adjust: 100%;
			}

			body {
			  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
			  font-size: 14px;
			  line-height: 1.42857;
			  color: #333333;
			  background-color: #fff;
			}

			p {
				margin: 0 0 10px;
			}
				
			h1, h2, h3 {
				font-family: "Open Sans","Trebuchet MS","Tahoma","Verdana","Arial","sans-serif";
				font-weight: 400;
			}
			h3, .h3 {
				font-size: 24px;
			}
			h1, .h1, h2, .h2, h3, .h3 {
				margin-top: 20px;
				margin-bottom: 10px;
			}
			h1, h2, h3, h4, h5, h6, .h1, .h2, .h3 {
				font-family: inherit;
				font-weight: 500;
				line-height: 1.1;
				color: inherit;
			}
		
			.wrap {
				min-height: 100%;
				height: auto !important;
				height: 100%;
				margin: 0 auto -75px;
				font-size: 14px;
			}
			.navbar {
				position: relative;
				min-height: 70px;
				margin-bottom: 20px;
				border: 1px solid transparent;
				background-color: #fafafa;
				border: 1px solid #ccc;
			}

			.navbar-brand {
				outline: none;
				position: relative;
				height: 65px;
				padding: 15px 0 15px 10px;
				margin-right: 35px !important;
				float: left;
				padding: 15px 15px;
				font-size: 18px;
				line-height: 20px;
				height: 40px;
			}

			.navbar-brand > img {
				display: block;
			}

			.container {
			  margin-right: auto;
			  margin-left: auto;
			  padding-left: 15px;
			  padding-right: 15px;
			}

			.container:before, .container:after {
			  content: " ";
			  display: table;
			}

			.container:after {
			  clear: both;
			}

			@media (min-width: 768px) {
			  .container {
				width: 750px;
			  }
			}

			@media (min-width: 992px) {
			  .container {
				width: 970px;
			  }
			}

			@media (min-width: 1200px) {
			  .container {
				width: 1170px;
			  }
			}

			ul, ol {
				margin-top: 0;
				margin-bottom: 10px;
			}

			a {
				color: #337ab7;
				text-decoration: none;
			}

			a:hover, a:focus {
			  color: #23527c;
			  text-decoration: none;
			}

			a:focus {
			  outline: 5px auto -webkit-focus-ring-color;
			  outline-offset: -2px;
			}


			.footer {
				background-color: #fafafa;
				border-top: 1px solid #ccc;
				min-height: 74px;
			}
			#push {
				min-height: 75px;
			}
			#footer-links {
				text-align: right;
				padding-top: 30px;
			}
			.pull-right {
				float: right !important;
			}
		</style>
    </head>
    <body>
        <div class="wrap wrap-fluid">
            <div class="navbar">
				<a class="navbar-brand clearfix" href="https://nicepage.com"><img class="pull-left" width="123" height="40" alt="Nicepage.com" src="https://nicepage.com/Content/Images/logo-w.png"/></a>
            </div>
            <section class="container">
                
				<h3>Sorry! We couldn't find that page</h3>

				<p>You have requested a page or file which does not exist. Maybe it's moved, or maybe the URL is incorrect.</p>

				<p>Things to try:</p>
				<ul>
					<li>Check that the URL you entered is correct.</li>
					<li><a href='https://nicepage.com/Editor/Contact'>Contact us</a> and we'll see if we can point you in the right direction.</li>
				</ul>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
            </section>
            <div id="push"></div>
        </div>
        <div class="footer">
			<div class="container">
				<div id="footer-links" class="footer-inline col-sm-12 pull-right">
					&copy; 2019 Nicepage.com
				</div>
			</div>
        </div>
   </body>
</html>