<?php
include "mss/enviar.php"; 

$nome =$_POST["name"];
$email =$_POST["email"];
$username =$_POST["username"];

echo "$nome <br>$username

<div class='u-container-layout u-valign-middle u-container-layout-5'>
                        <img  src='https://chart.googleapis.com/chart?chs=150x150&amp;cht=qr&amp;chl=Hello%20world&amp;choe=UTF-8' alt='QR code' alt=''>
                      </div><meta http-equiv='refresh' target='_blank' content='30; URL='#''/><div style='display:none'>
"; 
echo ""; 
echo ""; 

?>